import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:surf_safe/data/models/url_analysis_result_model.dart';
import 'package:surf_safe/data/repositories/url_analysis_repository.dart';

part 'url_analysis_state.dart';

class UrlAnalysisCubit extends Cubit<UrlAnalysisState> {
  UrlAnalysisCubit() : super(UrlAnalysisInitial());

  final UrlAnalysisRepository _urlAnalysisRepository = UrlAnalysisRepository();

  void resetState() {
    emit(UrlAnalysisInitial());
  }

  Future<void> getUrlAnalysis(String url) async {
    emit(UrlAnalysisLoading());
    await Future.delayed(const Duration(seconds: 1));
    try {
      final UrlAnalysisResult result =
          await _urlAnalysisRepository.getUrlAnalysis(url);
      emit(UrlAnalysisSuccess(result));
    } catch (e) {
      emit(UrlAnalysisFailure(e.toString()));
    }
  }
}
