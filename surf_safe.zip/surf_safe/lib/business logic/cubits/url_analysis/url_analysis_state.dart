part of 'url_analysis_cubit.dart';

sealed class UrlAnalysisState extends Equatable {
  const UrlAnalysisState();

  @override
  List<Object> get props => [];
}

final class UrlAnalysisInitial extends UrlAnalysisState {}

final class UrlAnalysisLoading extends UrlAnalysisState {}

final class UrlAnalysisSuccess extends UrlAnalysisState {
  final UrlAnalysisResult result;

  const UrlAnalysisSuccess(this.result);

  @override
  List<Object> get props => [result];
}

final class UrlAnalysisFailure extends UrlAnalysisState {
  final String message;

  const UrlAnalysisFailure(this.message);

  @override
  List<Object> get props => [message];
}
