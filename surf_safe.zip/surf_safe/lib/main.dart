import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:surf_safe/business%20logic/cubits/url_analysis/url_analysis_cubit.dart';
import 'package:surf_safe/presentation/screens/home_screen.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
        const SystemUiOverlayStyle(statusBarColor: Colors.transparent));
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => UrlAnalysisCubit()),
      ],
      child: MaterialApp(
        title: 'Surf Safe',
        debugShowCheckedModeBanner: false,
        initialRoute: "/home",
        routes: {
          "/home": (context) => const HomeScreen(),
        },
      ),
    );
  }
}
