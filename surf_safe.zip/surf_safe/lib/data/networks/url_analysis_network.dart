import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:surf_safe/data/models/url_analysis_result_model.dart';

class UrlAnalysisNetwork {
  Future<UrlAnalysisResult> getUrlAnalysis(String url) async {
    final response = await http.post(
      Uri.parse("http://surfsafe99.pythonanywhere.com/check-url"),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, String>{
        'url': url,
      }),
    );

    if (response.statusCode == 200) {
      return UrlAnalysisResult(
        analysisResultMessage: jsonDecode(response.body)['result'],
      );
    } else {
      throw Exception('Failed to check URL');
    }
  }
}
