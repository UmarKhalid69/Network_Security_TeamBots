import 'package:surf_safe/data/models/url_analysis_result_model.dart';
import 'package:surf_safe/data/networks/url_analysis_network.dart';

class UrlAnalysisRepository {
  final UrlAnalysisNetwork _urlAnalysisNetwork = UrlAnalysisNetwork();

  Future<UrlAnalysisResult> getUrlAnalysis(String url) async {
    return await _urlAnalysisNetwork.getUrlAnalysis(url);
  }
}
