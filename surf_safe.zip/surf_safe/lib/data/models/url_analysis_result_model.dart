class UrlAnalysisResult {
  String analysisResultMessage;

  UrlAnalysisResult({required this.analysisResultMessage});
}
