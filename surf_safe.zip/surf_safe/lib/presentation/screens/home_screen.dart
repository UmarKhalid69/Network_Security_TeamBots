import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:surf_safe/business%20logic/cubits/url_analysis/url_analysis_cubit.dart';
import 'package:surf_safe/presentation/widgets/responsive_vertical_spacer.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController urlController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.symmetric(
                horizontal: MediaQuery.of(context).size.width * 0.0963,
              ),
              child: BlocConsumer<UrlAnalysisCubit, UrlAnalysisState>(
                listener: (constext, state) {
                  if (state is UrlAnalysisSuccess) {
                    showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          title: const Text('Analysis Result'),
                          content: Text(state.result.analysisResultMessage),
                          actions: [
                            TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: const Text('Okay'),
                            ),
                          ],
                        );
                      },
                    );
                    context.read<UrlAnalysisCubit>().resetState();
                    urlController.clear();
                  } else if (state is UrlAnalysisFailure) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          "Analysis failed: ${state.message}",
                          style: const TextStyle(
                            color: Colors.white,
                          ),
                        ),
                        backgroundColor: Colors.red,
                      ),
                    );
                    context.read<UrlAnalysisCubit>().resetState();
                  }
                },
                builder: (context, state) {
                  return Column(
                    children: [
                      // title
                      const Text(
                        "Surf Safe",
                        style: TextStyle(
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      const ResponsiveVerticalSpacer(percentage: 1.8),

                      // url textfield
                      TextField(
                        controller: urlController,
                        decoration: const InputDecoration(
                          hintText: "Enter URL for analysis...",
                          border: OutlineInputBorder(),
                        ),
                      ),

                      const ResponsiveVerticalSpacer(percentage: 1.8),

                      // analyze button
                      ElevatedButton(
                        onPressed: state is UrlAnalysisInitial
                            ? () {
                                FocusManager.instance.primaryFocus?.unfocus();
                                context
                                    .read<UrlAnalysisCubit>()
                                    .getUrlAnalysis(urlController.text);
                              }
                            : () {},
                        child: state is UrlAnalysisInitial
                            ? const Text("Analyze")
                            : const CircularProgressIndicator(),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}
