import 'package:flutter/material.dart';

class ResponsiveVerticalSpacer extends StatelessWidget {
  const ResponsiveVerticalSpacer({
    super.key,
    required this.percentage,
  });

  final double percentage;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
        height: MediaQuery.sizeOf(context).height * (percentage / 100));
  }
}
