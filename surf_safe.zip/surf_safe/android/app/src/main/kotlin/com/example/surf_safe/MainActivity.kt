package com.example.surf_safe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
